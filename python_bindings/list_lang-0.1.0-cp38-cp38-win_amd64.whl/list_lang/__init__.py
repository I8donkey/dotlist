from .list_lang import *

__doc__ = list_lang.__doc__
if hasattr(list_lang, "__all__"):
    __all__ = list_lang.__all__